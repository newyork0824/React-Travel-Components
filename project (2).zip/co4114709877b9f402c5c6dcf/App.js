import React from "react"
import Header from "./Compon/Header"
import Card from "./Compon/Card"
import data from "./data"

export default function App(){
    const cards = data.map(item => {
    return (
     <Card 
key = {item.key}
{...item}
     />
    )
})


return (
   <div>
    <Header />
    {cards} 
   </div> 
    
)
}