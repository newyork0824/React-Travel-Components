import React from "react"


export default function Header(){
    return (
    <header>
     <p className= "header-title"> my travel journal </p>
    </header>
    )
}