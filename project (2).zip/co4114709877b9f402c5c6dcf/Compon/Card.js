import React from "react"

export default function Card(props){
    return (
      <div className="card">
       <img src={props.imageUrl} className="img" />
       <div className="trip-info">
       <h2 className="location"> {props.location} <span> <a className="link" href={props.googleMapsUrl}> View on Google Maps </a> </span> </h2>
       <h3 className="visited-area"> {props.title} </h3>
       <h4 className="dates-visited"> {props.startDate} - {props.endDate} </h4>
       <h5 className="description"> {props.description} </h5>

       </div>
      </div>  
        
        
    )
}